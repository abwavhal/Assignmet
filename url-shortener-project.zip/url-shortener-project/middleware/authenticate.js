const basicAuth = require('basic-auth');
const bcrypt = require('bcrypt');
const User = require('../models/user');

async function authenticate(req, res, next) {
    const userCredentials = basicAuth(req); // Extract credentials from request header
    const username = process.env.BASIC_AUTH_USERNAME;
    const password = process.env.BASIC_AUTH_PASSWORD;
    
    if (!userCredentials || userCredentials.name !== username || userCredentials.pass !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
    }
    
    req.userId = 'userId';  // You can store the user ID here after successful authentication
    // next();

    if (!userCredentials) {
        return res.status(401).json({ message: "Authentication required" });
    }

    try {
        // Find user by username
        const user = await User.findOne({ username: userCredentials.name });
        if (!user) {
            // If user doesn't exist, return 'Invalid credentials'
            return res.status(401).json({ message: "Invalid credentials" });
        }

        // Compare hashed password with the input password
        const isPasswordValid = await bcrypt.compare(userCredentials.pass, user.password);
        if (!isPasswordValid) {
            // If password doesn't match, return 'Invalid credentials'
            return res.status(401).json({ message: "Invalid credentials" });
        }

        // Store user ID in the request object for later use
        req.userId = user._id;
        // next(); // Proceed to the next middleware or route handler

    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: "Server error, please try again later" });
    }
}

module.exports = { authenticate };
