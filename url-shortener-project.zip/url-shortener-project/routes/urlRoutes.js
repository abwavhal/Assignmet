const express = require('express');
const router = express.Router();
const urlController = require('../controllers/urlController');
const { authenticate } = require('../middleware/authenticate');  // Import the authentication middleware

// Apply authentication middleware to any route that requires it
router.post('/shorten',authenticate, urlController.createShortUrl);   // Protect this route
router.get('/:shortUrl', urlController.redirectUrl);                 // No authentication needed here
router.get('/:shortUrl/analytics', authenticate, urlController.getAnalytics);  // Protect this route

module.exports = router;
