# URL Shortener Service

This project implements a URL shortener service with real-time analytics.

## Features:
- Shorten URLs
- Expiring links
- Visitor geography analytics
- Time-based click distribution
- Rate limiting
- Bulk shortening
- Basic authentication

## Setup:
1. Clone the repo
2. Install dependencies: `npm install`
3. Set up `.env` with `MONGO_URI` and other configurations
4. Run the app: `node server.js`

## API Endpoints:
- `POST /api/url/shorten`: Create short URL
- `GET /api/url/:shortUrl`: Redirect to original URL
- `GET /api/url/:shortUrl/analytics`: Get click and geographic analytics
