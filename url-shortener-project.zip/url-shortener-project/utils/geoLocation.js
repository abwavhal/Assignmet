const axios = require('axios');

async function getVisitorGeoData(visitors) {
    const ipAddresses = [...new Set(visitors.map(visitor => visitor.ip))];
    const geoData = {};

    for (let ip of ipAddresses) {
        try {
            const response = await axios.get(`https://ipinfo.io/${ip}/json`);
            const country = response.data.country;
            geoData[country] = (geoData[country] || 0) + 1;
        } catch (err) {
            console.error("Error fetching geolocation data", err);
        }
    }

    return geoData;
}

module.exports = { getVisitorGeoData };
