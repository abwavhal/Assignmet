const mongoose = require('mongoose');

const urlSchema = new mongoose.Schema({
    originalUrl: { type: String, required: true },
    shortUrl: { type: String, required: true, unique: true },
    expirationDate: { type: Date },
    clickCount: { type: Number, default: 0 },
    visitors: [{ ip: String, timestamp: Date }],
});

module.exports = mongoose.model('URL', urlSchema);
