const URL = require('../models/url');
const User = require('../models/user');
const { v4: uuidv4 } = require('uuid');
const moment = require('moment');
const axios = require('axios');
const geoLocation = require('../utils/geoLocation');

// Generate a short URL
async function createShortUrl(req, res) {
    const { originalUrl, expirationDate } = req.body;
    try {
        const user = await User.findById(req.userId); // Get user from authentication

        if (user.usageCount >= user.rateLimit) {
            return res.status(429).json({ message: "Rate limit exceeded" });
        }

        const shortUrl = uuidv4().slice(0, 8); // Generate a short 8-character URL

        const url = new URL({
            originalUrl,
            shortUrl,
            expirationDate: expirationDate ? moment(expirationDate).toDate() : null,
        });

        await url.save();
        user.usageCount += 1;
        await user.save();

        res.status(201).json({ shortUrl });
    } catch (error) {
        res.status(500).json({ message: "Error creating short URL", error });
    }
}

// Redirect to the original URL with analytics
async function redirectUrl(req, res) {
    const { shortUrl } = req.params;
    try {
        const url = await URL.findOne({ shortUrl });
        if (!url) {
            return res.status(404).json({ message: "URL not found" });
        }

        if (url.expirationDate && moment(url.expirationDate).isBefore(moment())) {
            return res.status(410).json({ message: "URL has expired" });
        }

        // Record visit and increment click count
        const visitorIp = req.ip; // Simplified for demo purposes
        const timestamp = moment().toDate();
        url.visitors.push({ ip: visitorIp, timestamp });
        url.clickCount += 1;
        await url.save();

        // Return the original URL
        return res.redirect(url.originalUrl);
        //res.redirect(url.originalUrl);
    } catch (error) {
        res.status(500).json({ message: "Error redirecting URL", error });
    }
}

// Fetch analytics for the URL
async function getAnalytics(req, res) {
    const { shortUrl } = req.params;
    try {
        const url = await URL.findOne({ shortUrl });
        if (!url) {
            return res.status(404).json({ message: "URL not found" });
        }

        const geoData = await geoLocation.getVisitorGeoData(url.visitors);
        res.status(200).json({
            clickCount: url.clickCount,
            visitorGeography: geoData,
        });
    } catch (error) {
        res.status(500).json({ message: "Error fetching analytics", error });
    }
}

module.exports = {
    createShortUrl,
    redirectUrl,
    getAnalytics,
};
