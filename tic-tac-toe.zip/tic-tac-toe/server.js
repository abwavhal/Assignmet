const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const { TicTacToe, Player } = require('./game');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

const game = new TicTacToe();

// Serve static files for a front-end (optional)
app.use(express.static('public'));

io.on('connection', socket => {
  console.log('a user connected:', socket.id);

  // Player joins the game
  socket.on('joinGame', (playerName) => {
    const player = new Player(playerName, socket.id === 'player1' ? 'X' : 'O');
    if (game.addPlayer(player)) {
      socket.emit('gameStarted', { symbol: player.symbol });
      if (game.players.length === 2) {
        io.emit('turn', { currentPlayer: game.currentPlayer.name });
      }
    }
  });

  // Make a move
  socket.on('makeMove', (row, col) => {
    try {
      if (game.currentPlayer.symbol === socket.id) {
        if (!game.isValidMove(row, col)) {
          socket.emit('error', 'Invalid move! Try again.');
          return;
        }
        game.makeMove(row, col);
        if (game.checkWin()) {
          io.emit('gameOver', { winner: game.currentPlayer.name });
        } else if (game.isBoardFull()) {
          io.emit('gameOver', { winner: null });
        } else {
          game.switchPlayer();
          io.emit('turn', { currentPlayer: game.currentPlayer.name });
        }
      } else {
        socket.emit('error', 'Not your turn!');
      }
    } catch (error) {
      socket.emit('error', error.message);
    }
  });

  // Use special move
  socket.on('useSpecialMove', (moveType, row, col, targetRow, targetCol) => {
    try {
      if (game.currentPlayer.symbol === socket.id) {
        game.useSpecialMove(moveType, row, col, targetRow, targetCol);
        io.emit('boardUpdate', game.board);
      }
    } catch (error) {
      socket.emit('error', error.message);
    }
  });

  socket.on('disconnect', () => {
    console.log('user disconnected');
  });
});

server.listen(3000, () => {
  console.log('listening on *:3000');
});
