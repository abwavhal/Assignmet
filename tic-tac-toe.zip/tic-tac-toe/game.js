class TicTacToe {
    constructor() {
      this.board = [
        ['', '', ''],
        ['', '', ''],
        ['', '', ''],
      ];
      this.players = [];
      this.currentPlayer = null;
      this.turnTimer = 30;
      this.specialMoves = {
        'swap': 3,
        'block': 3,
        'powerMove': 3,
      };
    }
  
    // Initialize the game with players
    addPlayer(player) {
      if (this.players.length < 2) {
        this.players.push(player);
        if (this.players.length === 1) {
          this.currentPlayer = player;
        }
        return true;
      }
      return false;
    }
  
    // Switch the current player
    switchPlayer() {
      this.currentPlayer = this.players.find(player => player !== this.currentPlayer);
    }
  
    // Check if a player has won
    checkWin() {
      const board = this.board;
      for (let i = 0; i < 3; i++) {
        if (board[i][0] && board[i][0] === board[i][1] && board[i][0] === board[i][2]) return true; // Row check
        if (board[0][i] && board[0][i] === board[1][i] && board[0][i] === board[2][i]) return true; // Column check
      }
      if (board[0][0] && board[0][0] === board[1][1] && board[0][0] === board[2][2]) return true; // Diagonal check
      if (board[0][2] && board[0][2] === board[1][1] && board[0][2] === board[2][0]) return true; // Anti-diagonal check
      return false;
    }
  
    // Check if the board is full
    isBoardFull() {
      return this.board.every(row => row.every(cell => cell !== ''));
    }
  
    // Make a move
    makeMove(row, col) {
      if (this.board[row][col] !== '') {
        throw new Error('Cell already occupied!');
      }
      this.board[row][col] = this.currentPlayer.symbol;
    }
  
    // Use a special move
    useSpecialMove(moveType, row, col, targetRow, targetCol) {
      if (this.specialMoves[moveType] <= 0) {
        throw new Error('No special moves left!');
      }
  
      switch (moveType) {
        case 'swap':
          this.swapPositions(row, col, targetRow, targetCol);
          break;
        case 'block':
          this.blockCell(row, col);
          break;
        case 'powerMove':
          this.powerMove(row, col);
          break;
        default:
          throw new Error('Invalid special move');
      }
  
      this.specialMoves[moveType]--;
    }
  
    // Swap positions of two cells
    swapPositions(row1, col1, row2, col2) {
      const temp = this.board[row1][col1];
      this.board[row1][col1] = this.board[row2][col2];
      this.board[row2][col2] = temp;
    }
  
    // Block a cell for the next two turns
    blockCell(row, col) {
      this.board[row][col] = 'BLOCKED';
    }
  
    // Power move: Player can place their mark on any occupied space
    powerMove(row, col) {
      this.board[row][col] = this.currentPlayer.symbol;
    }
  
    // Check if a move is valid
    isValidMove(row, col) {
      return row >= 0 && col >= 0 && row < 3 && col < 3 && this.board[row][col] === '';
    }
  }
  
  class Player {
    constructor(name, symbol) {
      this.name = name;
      this.symbol = symbol;
    }
  }
  
  module.exports = { TicTacToe, Player };
  