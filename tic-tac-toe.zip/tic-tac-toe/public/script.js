const socket = io();
let playerSymbol = '';
let currentPlayer = '';

document.querySelectorAll('.cell').forEach(cell => {
    cell.addEventListener('click', () => {
        const row = cell.dataset.row;
        const col = cell.dataset.col();
        makeMove(row, col);
    });
});

// Join the game with player name (prompt for simplicity)
const playerName = prompt('Enter your name');
socket.emit('joinGame', playerName);

// Handle game start
socket.on('gameStarted', (data) => {
    playerSymbol = data.symbol;
    document.querySelector('.status').textContent = `You are Player ${playerSymbol}. Waiting for the other player...`;
});

// Handle the player's turn
socket.on('turn', (data) => {
    currentPlayer = data.currentPlayer;
    document.querySelector('.status').textContent = `It's ${currentPlayer}'s turn.`;
});

// Handle invalid move or error
socket.on('error', (message) => {
    alert(message);
});

// Handle board update
socket.on('boardUpdate', (board) => {
    updateBoard(board);
});

// Handle game over
socket.on('gameOver', (data) => {
    if (data.winner) {
        document.querySelector('.status').textContent = `${data.winner} wins!`;
    } else {
        document.querySelector('.status').textContent = 'The game is a draw!';
    }
    disableBoard();
});

// Function to make a move
function makeMove(row, col) {
    if (currentPlayer === playerSymbol) {
        socket.emit('makeMove', row, col);
    } else {
        alert("It's not your turn!");
    }
}

// Function to update the board
function updateBoard(board) {
    const cells = document.querySelectorAll('.cell');
    board.forEach((row, rowIndex) => {
        row.forEach((cell, colIndex) => {
            const index = rowIndex * 3 + colIndex;
            cells[index].textContent = cell;
        });
    });
}

// Disable the board after the game ends
function disableBoard() {
    document.querySelectorAll('.cell').forEach(cell => {
        cell.style.pointerEvents = 'none';
    });
}

// Use special moves
function useSpecialMove(moveType) {
    const row = parseInt(prompt('Enter row for the special move (0-2)'));
    const col = parseInt(prompt('Enter column for the special move (0-2)'));

    if (moveType === 'swap') {
        const targetRow = parseInt(prompt('Enter target row for swap (0-2)'));
        const targetCol = parseInt(prompt('Enter target column for swap (0-2)'));
        socket.emit('useSpecialMove', moveType, row, col, targetRow, targetCol);
    } else {
        socket.emit('useSpecialMove', moveType, row, col);
    }
}
